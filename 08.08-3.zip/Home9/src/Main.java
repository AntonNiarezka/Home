import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //Задание 3
        Scanner scr1 = new Scanner(System.in);
        System.out.println("Ваше первое число:");
        int number1 = scr1.nextInt();
        System.out.println("Ваше второе число:");
        int number2 = scr1.nextInt();
        System.out.println("Сумма: " + (number1 + number2));
        System.out.println("Разность: " + (number1 - number2));
        System.out.println("Произведение: " + (number1 * number2));
        System.out.println("Частное: " + (number1 / number2));





    }
}

