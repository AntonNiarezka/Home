import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //1 Вывести на экран цифры от 0 до 10.
        //2 Пользователь вводит два числа – начало и конец диапазона.
        // Программа должна посчитать сумму всех чисел в указанном диапазоне.
        // Пользователь может ввести сначала меньшее, потом большее число или наоборот.
        //3 Вывести в консоль каждую вторую букву латинского алфавита

        for (int i = 0; i <= 10; i++) {
            System.out.println(i);
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите первое число -");
        int first = scanner.nextInt();
        System.out.println("Введите второе число -");
        int second = scanner.nextInt();
        int sum = 0;
        for (int i = Math.min(first, second); i <= Math.max(first, second); i++) {

            sum = sum + i;  // либо более коротко +=i

        System.out.println(sum);}

    }


}