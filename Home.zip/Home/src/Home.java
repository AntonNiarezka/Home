
public class Home {

    public static void main(String[] arg ){

        System.out.println("Unfortunately it is not possible to download JDK 8, it is not in the list");
        


    }

}