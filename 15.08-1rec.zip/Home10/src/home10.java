import java.util.Scanner;

import static java.lang.Math.abs;


public class home10 {
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое число n");
        double n = scr.nextDouble();
        System.out.println("Введите второе число m");
        double m = scr.nextDouble();
        if ((abs(10 - m) < abs(10 - n))) {
            System.out.println("Число " + m + " ближе к 10");
        } else {
            System.out.println("Число " + n + " Ближе к 10");
        }


    }
}
