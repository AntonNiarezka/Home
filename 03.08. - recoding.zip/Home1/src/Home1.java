public class Home1 {
    public static void main(String[] args) {

         int i  = 589 ;

         System.out.println(i + " -> ");
        System.out.println(i / 100 + " , ");
        System.out.println(i / 10 % 10 + " , ");
        System.out.println(i  % 10 + " , ");

    }
}
