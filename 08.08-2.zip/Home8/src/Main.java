import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.print("Ваше имя: ");
        String name = scr.nextLine();
        System.out.print("Ваш возраст: ");
        int age = scr.nextInt();
        System.out.println("Ваш вес: ");
        int weight = scr.nextInt();
        System.out.println("Уважаемый(ая) " + name + " в свои " + age
                + " Вы для нас дороги как "
                + weight + " кг" + " золотa!");


    }
}