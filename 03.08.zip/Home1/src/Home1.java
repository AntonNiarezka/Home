public class Home1 {
    public static void main(String[] args) {


        String Liter ="G" ;

         int Num = 89 ;

         byte Numome = 4;

         short Numtvo = 56;

         float Numthree = 4.7333436F;

         double Numfor = 4.355453532;

         long Numfive = 12121L;

         System.out.println("345"+":" + "3,4,5");

    }
}
