public class Main {
    public static void main(String[] args) {

        // В экспедицию должна поехать бригада изыскателей. Обязательно должен поехать бригадир.
        // и/или его заместитель. Кроме того должен поехать геодезист и геолог
        // Обязательно должен поехать один из двух водителей, но не оба одновременно.
        // Составьте логическое выражение для поездки в экспедицию и задайте начальные переменные так,
        // чтобы экспедиция состоялась (т.е. логическое выражение было истинным)

        boolean isBrigadirPries = true;
        boolean isZamPries = true;
        boolean isGeodezPries = true;
        boolean isGeologPries = true;
        boolean isDriverOne = false;
        boolean isDriverTvo = true;

        boolean isExpiditionHappen = (isBrigadirPries || isZamPries) && (isGeodezPries && isGeologPries)
                &&(isDriverOne ^ isDriverTvo);

        System.out.println(isExpiditionHappen);



    }
}